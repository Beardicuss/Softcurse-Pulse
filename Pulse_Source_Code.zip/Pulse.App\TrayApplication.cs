using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Pulse.Core;

namespace Pulse.App
{
    public class TrayApplication : ApplicationContext
    {
        private NotifyIcon _notifyIcon;
        private List<IModule> _modules;

        public TrayApplication(List<IModule> modules)
        {
            _modules = modules;
            InitializeContext();
        }

        private void InitializeContext()
        {
            var contextMenu = new ContextMenuStrip();
            contextMenu.Items.Add("Pulse Status: Running", null, (s, e) => { });
            contextMenu.Items.Add("-");
            
            foreach (var module in _modules)
            {
                var item = new ToolStripMenuItem($"{module.Name}: {(module.IsEnabled ? "Enabled" : "Disabled")}");
                item.Click += (s, e) => {
                    module.IsEnabled = !module.IsEnabled;
                    item.Text = $"{module.Name}: {(module.IsEnabled ? "Enabled" : "Disabled")}";
                    Logger.Info($"{module.Name} is now {(module.IsEnabled ? "Enabled" : "Disabled")}");
                };
                contextMenu.Items.Add(item);
            }

            contextMenu.Items.Add("-");
            contextMenu.Items.Add("Exit", null, (s, e) => Exit());

            _notifyIcon = new NotifyIcon()
            {
                Icon = SystemIcons.Application, // Use default app icon for MVP
                ContextMenuStrip = contextMenu,
                Text = "Pulse - Network & Process Monitor",
                Visible = true
            };

            _notifyIcon.BalloonTipTitle = "Pulse Started";
            _notifyIcon.BalloonTipText = "Pulse is now monitoring your system in the background.";
            _notifyIcon.ShowBalloonTip(3000);
        }

        private void Exit()
        {
            _notifyIcon.Visible = false;
            Application.Exit();
        }
    }
}
