using System;
using System.Threading.Tasks;

namespace Pulse.Core
{
    public class ActionEngine : IModule
    {
        public string Name => "Action Engine";
        public bool IsEnabled { get; set; } = true;

        public async Task StartAsync()
        {
            Logger.Info("Action Engine initialized.");
            await Task.CompletedTask;
        }

        public async Task StopAsync()
        {
            await Task.CompletedTask;
        }

        public void ExecuteAction(string trigger, Action action)
        {
            Logger.Info($"Triggered action for: {trigger}");
            try
            {
                action.Invoke();
            }
            catch (Exception ex)
            {
                Logger.Error($"Action execution failed: {ex.Message}");
            }
        }

        // Example action: Notify user (placeholder for real notification)
        public void NotifyUser(string message)
        {
            Logger.Info($"NOTIFICATION: {message}");
        }
    }
}
