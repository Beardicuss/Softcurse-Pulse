using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pulse.Core;

namespace Pulse.App
{
    static class Program
    {
        [STAThread]
        static async Task Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Logger.Info("Pulse is starting...");

            var modules = new List<IModule>
            {
                new NetworkMonitor(),
                new ProcessMonitor(),
                new ActionEngine()
            };

            foreach (var module in modules)
            {
                if (module.IsEnabled)
                {
                    Logger.Info($"Starting module: {module.Name}");
                    await module.StartAsync();
                }
            }

            // Run the tray application
            var trayApp = new TrayApplication(modules);
            
            // We use Task.Run to keep the UI thread separate if needed, 
            // but Application.Run blocks, so we handle shutdown via the tray app.
            Application.Run(trayApp);

            Logger.Info("Pulse is shutting down...");
            foreach (var module in modules)
            {
                await module.StopAsync();
            }
        }
    }
}
