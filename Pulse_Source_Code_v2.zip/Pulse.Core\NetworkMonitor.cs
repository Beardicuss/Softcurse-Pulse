using System;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;

namespace Pulse.Core
{
    public class NetworkMonitor : IModule
    {
        public string Name => "Network Monitor";
        public bool IsEnabled { get; set; } = true;

        private CancellationTokenSource _cts;
        private const string TargetHost = "8.8.8.8"; // Google DNS
        private const int IntervalMs = 5000; // 5 seconds

        public async Task StartAsync()
        {
            _cts = new CancellationTokenSource();
            _ = Task.Run(() => MonitorLoop(_cts.Token));
            await Task.CompletedTask;
        }

        public async Task StopAsync()
        {
            _cts?.Cancel();
            await Task.CompletedTask;
        }

        private async Task MonitorLoop(CancellationToken token)
        {
            using var ping = new Ping();
            while (!token.IsCancellationRequested)
            {
                try
                {
                    var reply = await ping.SendPingAsync(TargetHost, 2000);
                    if (reply.Status == IPStatus.Success)
                    {
                        Logger.Info($"Network OK: Latency {reply.RoundtripTime}ms");
                    }
                    else
                    {
                        Logger.Warning($"Network Issue: {reply.Status}");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Network Monitor Error: {ex.Message}");
                }

                await Task.Delay(IntervalMs, token);
            }
        }
    }
}
