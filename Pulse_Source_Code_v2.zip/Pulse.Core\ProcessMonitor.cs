using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Pulse.Core
{
    public class ProcessMonitor : IModule
    {
        public string Name => "Process Monitor";
        public bool IsEnabled { get; set; } = true;

        private CancellationTokenSource _cts;
        private const int IntervalMs = 10000; // 10 seconds
        private const double CpuThreshold = 80.0; // 80% CPU usage

        public async Task StartAsync()
        {
            _cts = new CancellationTokenSource();
            _ = Task.Run(() => MonitorLoop(_cts.Token));
            await Task.CompletedTask;
        }

        public async Task StopAsync()
        {
            _cts?.Cancel();
            await Task.CompletedTask;
        }

        private async Task MonitorLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    var processes = Process.GetProcesses();
                    // In a real MVP, we'd track CPU usage over time for each process.
                    // For this lightweight version, we'll just log the total count and check for high memory usage as a proxy for "spikes".
                    
                    var highMemoryProcesses = processes
                        .Where(p => p.WorkingSet64 > 500 * 1024 * 1024) // > 500MB
                        .OrderByDescending(p => p.WorkingSet64)
                        .Take(3);

                    foreach (var p in highMemoryProcesses)
                    {
                        Logger.Warning($"High Memory Process: {p.ProcessName} ({p.WorkingSet64 / 1024 / 1024} MB)");
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Process Monitor Error: {ex.Message}");
                }

                await Task.Delay(IntervalMs, token);
            }
        }
    }
}
